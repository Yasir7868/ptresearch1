'use client';

import { useState } from 'react';
import { redirectToGatewayCheckout, type GatewayOrder } from 'payment-gateway-checkout';

type Props = {
  order: GatewayOrder;
};

export function GatewayCheckoutButton({ order }: Props) {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  async function handleClick() {
    setIsLoading(true);
    setError('');

    try {
      await redirectToGatewayCheckout({
        order,
        successUrl: `${window.location.origin}/checkout/success?order=${order.id}`,
        cancelUrl: `${window.location.origin}/checkout`,
      });
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Checkout failed');
      setIsLoading(false);
    }
  }

  return (
    <div>
      <button type="button" disabled={isLoading} onClick={handleClick}>
        {isLoading ? 'Opening Payment Gateway...' : 'Pay with Payment Gateway'}
      </button>
      {error ? <p role="alert">{error}</p> : null}
    </div>
  );
}
