'use client';

import { useEffect, useRef, useState } from 'react';
import {
  fetchGatewayEmbeddedCheckoutSession,
  mountGatewayEmbeddedCheckout,
  type GatewayEmbeddedCheckoutMount,
  type GatewayOrder,
} from 'payment-gateway-checkout';

type Props = {
  order: GatewayOrder;
};

export function GatewayEmbeddedCheckout({ order }: Props) {
  const mountRef = useRef<GatewayEmbeddedCheckoutMount | null>(null);
  const [error, setError] = useState('');
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    let isCancelled = false;

    async function start() {
      try {
        const session = await fetchGatewayEmbeddedCheckoutSession({
          order,
          successUrl: `${window.location.origin}/checkout/success?order=${order.id}`,
          cancelUrl: `${window.location.origin}/checkout`,
          returnUrl: `${window.location.origin}/checkout/success?order=${order.id}&session_id={CHECKOUT_SESSION_ID}`,
          checkoutId: order.key,
        });

        if (isCancelled) {
          return;
        }

        mountRef.current = await mountGatewayEmbeddedCheckout({
          clientSecret: session.client_secret,
          publishableKey: session.publishable_key,
          connectedAccountId: session.connected_account_id,
          checkoutSelector: '#embedded-checkout',
          onReady: () => setIsReady(true),
          onComplete: () => {
            window.location.href = `${window.location.origin}/checkout/success?order=${order.id}&session_id=${encodeURIComponent(
              session.checkout_session_id,
            )}`;
          },
        });
      } catch (caught) {
        setError(caught instanceof Error ? caught.message : 'Payment setup failed');
      }
    }

    void start();

    return () => {
      isCancelled = true;
      mountRef.current?.destroy();
      mountRef.current = null;
    };
  }, [order.id, order.key, order.total, order.currency]);

  return (
    <div>
      <div id="embedded-checkout" />
      <p id="payment-error" role="alert">
        {error}
      </p>
      <button type="button" disabled>
        {isReady ? 'Secure checkout ready' : 'Loading secure checkout...'}
      </button>
    </div>
  );
}
