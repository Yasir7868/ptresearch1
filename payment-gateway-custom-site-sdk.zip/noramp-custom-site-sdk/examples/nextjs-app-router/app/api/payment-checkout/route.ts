import { NextResponse } from 'next/server';
import { createGatewayServerClient } from 'payment-gateway-checkout';

const gateway = createGatewayServerClient({
  apiBaseUrl: process.env.PAYMENT_GATEWAY_API_BASE_URL!,
  merchantToken: process.env.PAYMENT_GATEWAY_MERCHANT_TOKEN!,
});

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const session = await gateway.createCheckoutSession({
      order: body.order,
      success_url: body.success_url,
      cancel_url: body.cancel_url,
      callback_url: `${process.env.NEXT_PUBLIC_SITE_URL}/api/payment-callback`,
    });

    return NextResponse.json(session);
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Checkout failed' },
      { status: 400 },
    );
  }
}
