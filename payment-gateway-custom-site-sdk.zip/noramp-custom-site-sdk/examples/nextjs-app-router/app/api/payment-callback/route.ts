import { NextResponse } from 'next/server';
import { verifyGatewayCallbackSignature } from 'payment-gateway-checkout';

export async function POST(request: Request) {
  const rawBody = await request.text();
  const signature = request.headers.get('x-platform-signature');
  const isValid = await verifyGatewayCallbackSignature({
    rawBody,
    signature,
    merchantToken: process.env.PAYMENT_GATEWAY_MERCHANT_TOKEN!,
  });

  if (!isValid) {
    return NextResponse.json({ error: 'Invalid signature' }, { status: 401 });
  }

  const event = JSON.parse(rawBody);

  // Update your own order database here.
  // event.event can be: payment.succeeded, payment.failed, checkout.session.expired
  console.log('Payment Gateway callback', event);

  return NextResponse.json({ ok: true });
}
