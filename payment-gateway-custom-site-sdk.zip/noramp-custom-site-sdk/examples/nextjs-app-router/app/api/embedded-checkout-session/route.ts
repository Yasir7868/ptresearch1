import { NextResponse } from 'next/server';
import { createGatewayServerClient } from 'payment-gateway-checkout';

const gateway = createGatewayServerClient({
  apiBaseUrl: process.env.PAYMENT_GATEWAY_API_BASE_URL!,
  merchantToken: process.env.PAYMENT_GATEWAY_MERCHANT_TOKEN!,
});

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const stableCheckoutKey = body.checkout_id || body.idempotency_key;
    const session = await gateway.createEmbeddedCheckoutSession({
      order: body.order,
      success_url: body.success_url,
      cancel_url: body.cancel_url,
      return_url: body.return_url,
      redirect_on_completion: body.redirect_on_completion || 'if_required',
      callback_url: `${process.env.NEXT_PUBLIC_SITE_URL}/api/payment-callback`,
      checkout_id: stableCheckoutKey,
      idempotency_key: stableCheckoutKey,
    });

    return NextResponse.json(session);
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Payment setup failed' },
      { status: 400 },
    );
  }
}
