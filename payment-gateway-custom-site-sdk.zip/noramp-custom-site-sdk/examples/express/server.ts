import express from 'express';
import {
  createGatewayServerClient,
  verifyGatewayCallbackSignature,
} from 'payment-gateway-checkout';

const app = express();
const gateway = createGatewayServerClient({
  apiBaseUrl: process.env.PAYMENT_GATEWAY_API_BASE_URL!,
  merchantToken: process.env.PAYMENT_GATEWAY_MERCHANT_TOKEN!,
});

app.post('/api/payment-checkout', express.json(), async (req, res) => {
  try {
    const session = await gateway.createCheckoutSession({
      order: req.body.order,
      success_url: req.body.success_url,
      cancel_url: req.body.cancel_url,
      callback_url: `${process.env.SITE_URL}/api/payment-callback`,
      checkout_id: req.body.checkout_id,
      idempotency_key: req.body.idempotency_key,
    });

    res.json(session);
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : 'Checkout failed' });
  }
});

app.post('/api/embedded-checkout-session', express.json(), async (req, res) => {
  try {
    const stableCheckoutKey = req.body.checkout_id || req.body.idempotency_key;
    const session = await gateway.createEmbeddedCheckoutSession({
      order: req.body.order,
      success_url: req.body.success_url,
      cancel_url: req.body.cancel_url,
      return_url: req.body.return_url,
      redirect_on_completion: req.body.redirect_on_completion || 'if_required',
      callback_url: `${process.env.SITE_URL}/api/payment-callback`,
      checkout_id: stableCheckoutKey,
      idempotency_key: stableCheckoutKey,
    });

    res.json(session);
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : 'Payment setup failed' });
  }
});

app.post('/api/payment-callback', express.raw({ type: 'application/json' }), async (req, res) => {
  const rawBody = req.body.toString('utf8');
  const isValid = await verifyGatewayCallbackSignature({
    rawBody,
    signature: req.header('x-platform-signature'),
    merchantToken: process.env.PAYMENT_GATEWAY_MERCHANT_TOKEN!,
  });

  if (!isValid) {
    return res.status(401).json({ error: 'Invalid signature' });
  }

  const event = JSON.parse(rawBody);

  // Update your own order database here.
  console.log('Payment Gateway callback', event);

  return res.json({ ok: true });
});

app.listen(Number(process.env.PORT || 3000), () => {
  console.log('Example app listening');
});
