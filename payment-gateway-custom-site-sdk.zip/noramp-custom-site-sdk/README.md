# Payment Gateway Custom Site Checkout SDK

Use this package when a merchant has a custom TypeScript site instead of WooCommerce.

The merchant site never receives processor secret keys. Store the merchant token only in server environment variables. Browser code may receive the Stripe publishable key, connected account ID, and embedded Checkout Session client secret returned by your server route.

## Merchant Setup Fields

```text
PAYMENT_GATEWAY_API_BASE_URL=https://your-platform-api.example
PAYMENT_GATEWAY_MERCHANT_TOKEN=merchant_token_from_platform
SITE_URL=https://merchant.example.com
```

## Checkout Options

This SDK supports:

```text
Embedded Checkout Session: customer pays in a secure embedded Stripe checkout surface.
Hosted redirect checkout: customer leaves the site and pays on hosted checkout.
```

Use embedded Checkout for the white-label custom-site checkout. Mastercard is blocked by the platform when creating Checkout Sessions. Apple Pay and Google Pay can appear when the merchant domain, browser, wallet, currency, and processor settings are eligible.

Before enabling Apple Pay or Google Pay, register the checkout domain from a server-only setup route:

```ts
await gateway.registerPaymentMethodDomain({
  site_url: process.env.SITE_URL!,
  include_www: true,
});
```

## Server Route: Embedded Checkout

Create a server route such as `/api/embedded-checkout-session`. This route must run server-side because it uses the merchant token.

```ts
import { createGatewayServerClient } from 'payment-gateway-checkout';

const gateway = createGatewayServerClient({
  apiBaseUrl: process.env.PAYMENT_GATEWAY_API_BASE_URL!,
  merchantToken: process.env.PAYMENT_GATEWAY_MERCHANT_TOKEN!,
});

export async function POST(request: Request) {
  const body = await request.json();
  const stableCheckoutKey = body.checkout_id || body.idempotency_key;

  const session = await gateway.createEmbeddedCheckoutSession({
    order: body.order,
    checkout_id: stableCheckoutKey,
    idempotency_key: stableCheckoutKey,
    success_url: body.success_url,
    cancel_url: body.cancel_url,
    return_url: body.return_url,
    redirect_on_completion: 'if_required',
    callback_url: `${process.env.SITE_URL}/api/payment-callback`,
    source: 'custom_site',
    company_name: body.company_name,
    compliance: {
      buyer_type: 'business_or_lab',
      use_case: 'in_vitro_research',
      product_category: 'ruo_reference_materials',
      site_acknowledgment: 'research_use_only',
      not_for_consumption_acknowledged: true,
      coa_available: true,
      shipping_contains: 'research_materials',
    },
  });

  return Response.json(session);
}
```

The response includes:

```ts
type GatewayEmbeddedCheckoutResponse = {
  checkout_session_id: string;
  session_id: string;
  client_secret: string;
  publishable_key: string;
  connected_account_id?: string;
  amount: number;
  currency: string;
};
```

## Browser: Mount Embedded Checkout

Call the embedded Checkout endpoint once per real checkout, not once per render. Use the same `checkoutId` while the customer is editing the same cart, and only change it when the cart becomes a genuinely new checkout. Good values are a server-side cart ID, a persisted checkout session ID, or the final order ID once it exists.

```ts
import {
  fetchGatewayEmbeddedCheckoutSession,
  mountGatewayEmbeddedCheckout,
} from 'payment-gateway-checkout';

const session = await fetchGatewayEmbeddedCheckoutSession({
  order,
  checkoutId: order.key,
  source: 'custom_site',
  companyName: order.customer?.company,
  compliance: {
    buyer_type: 'business_or_lab',
    use_case: 'in_vitro_research',
    product_category: 'ruo_reference_materials',
    site_acknowledgment: 'research_use_only',
    not_for_consumption_acknowledged: true,
    coa_available: true,
    shipping_contains: 'research_materials',
  },
  successUrl: `${window.location.origin}/checkout/success?order=${order.id}`,
  cancelUrl: `${window.location.origin}/checkout`,
  returnUrl: `${window.location.origin}/checkout/success?order=${order.id}&session_id={CHECKOUT_SESSION_ID}`,
});

await mountGatewayEmbeddedCheckout({
  clientSecret: session.client_secret,
  publishableKey: session.publishable_key,
  connectedAccountId: session.connected_account_id,
  checkoutSelector: '#embedded-checkout',
  onComplete: () => {
    window.location.href = `${window.location.origin}/checkout/success?order=${order.id}&session_id=${encodeURIComponent(
      session.checkout_session_id,
    )}`;
  },
});
```

Minimal HTML:

```html
<div id="embedded-checkout"></div>
```

## Server Route: Hosted Redirect Checkout

Use this if the merchant wants the older redirect flow.

```ts
const session = await gateway.createCheckoutSession({
  order,
  success_url: 'https://merchant.example.com/checkout/success',
  cancel_url: 'https://merchant.example.com/checkout',
  callback_url: 'https://merchant.example.com/api/payment-callback',
  source: 'custom_site',
  company_name: order.customer?.company,
});
```

## Browser: Redirect Button

```ts
import { redirectToGatewayCheckout } from 'payment-gateway-checkout';

await redirectToGatewayCheckout({
  order,
  source: 'custom_site',
  companyName: order.customer?.company,
  successUrl: `${window.location.origin}/checkout/success`,
  cancelUrl: `${window.location.origin}/checkout`,
});
```

By default, the browser helper calls `/api/payment-checkout`. Override it with `endpoint` if needed.

## Connection Test

Run this from a server-only admin or setup route before enabling live checkout:

```ts
const readiness = await gateway.testConnection({
  callback_url: 'https://merchant.example.com/api/payment-callback',
  site_url: 'https://merchant.example.com',
});
```

## Callback Verification

Payment callbacks are signed with:

```text
hmac_sha256(raw_json_body, sha256(PAYMENT_GATEWAY_MERCHANT_TOKEN))
```

Verify callbacks before updating the merchant order database:

```ts
import { verifyGatewayCallbackSignature } from 'payment-gateway-checkout';

const isValid = await verifyGatewayCallbackSignature({
  rawBody,
  signature: request.headers.get('x-platform-signature'),
  merchantToken: process.env.PAYMENT_GATEWAY_MERCHANT_TOKEN!,
});
```

## Success Page Reconciliation

Callbacks are the source of truth. A success page can also reconcile the Checkout Session if needed:

```ts
await gateway.reconcileCheckoutSession({
  checkout_session_id: sessionId,
  order_id: orderId,
  order_key: orderKey,
});
```

## What The AI Builder Needs

Give the AI builder:

```text
This SDK folder
PAYMENT_GATEWAY_API_BASE_URL
PAYMENT_GATEWAY_MERCHANT_TOKEN
The site's order/cart shape
The desired success, cancel, and return URLs
```

Tell it:

```text
Create a server route at /api/embedded-checkout-session using createGatewayServerClient.
Create a callback route at /api/payment-callback using verifyGatewayCallbackSignature.
Render #embedded-checkout in checkout.
Call fetchGatewayEmbeddedCheckoutSession and mountGatewayEmbeddedCheckout from browser checkout code.
Call the embedded-checkout-session route once per stable checkout_id; do not call it inside render loops.
Never expose PAYMENT_GATEWAY_MERCHANT_TOKEN in browser code.
```
